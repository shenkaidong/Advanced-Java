package com.antra.demo.customer.exception;

public class UserNotFoundException extends RuntimeException {
}
